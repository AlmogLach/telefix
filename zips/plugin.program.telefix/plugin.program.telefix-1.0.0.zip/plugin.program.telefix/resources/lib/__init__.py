# Telefix resources
